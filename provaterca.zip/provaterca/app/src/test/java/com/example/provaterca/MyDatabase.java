package com.example.appdetarefas;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Tarefa.class}, version = 1)
public abstract class MyDatabase extends RoomDatabase {

    public abstract TarefaDAO tarefaDAO();
}
