package com.example.provaterca;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText descricaoTarefa;
    private Button salvarTarefa;
    private RecyclerView recyclerView;
    private com.example.appdetarefas.TarefaAdapter adapter;
    private MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        descricaoTarefa = findViewById(R.id.editTextDescricaoTarefa);
        salvarTarefa = findViewById(R.id.buttonSalvarTarefa);
        recyclerView = findViewById(R.id.recyclerViewTarefas);

        db = Room.databaseBuilder(getApplicationContext(),
                MyDatabase.class, "tarefas.db").build();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new com.example.appdetarefas.TarefaAdapter(new java.util.ArrayList<com.example.appdetarefas.Tarefa>(), new TarefaAdapter.OnItemClickListener() {
            @Override
            public void onCheckBoxClick(com.example.appdetarefas.Tarefa tarefa, boolean isChecked) {
                tarefa.setFeita(isChecked);
                atualizarTarefa(tarefa);
            }

            @Override
            public void onDeleteClick(Tarefa tarefa) {
                deletarTarefa(tarefa);
            }
        });
        recyclerView.setAdapter(adapter);

        salvarTarefa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarTarefa();
            }
        });

        carregarTarefas();
    }

    private void salvarTarefa() {
        final String descricao = descricaoTarefa.getText().toString().trim();

        if (descricao.isEmpty()) {
            Toast.makeText(MainActivity.this, "Digite a descrição da tarefa", Toast.LENGTH_SHORT).show();
            return;
        }

        final Tarefa tarefa = new Tarefa(0, descricao, false);

        new Thread(new Runnable() {
            @Override
            public void run() {
                db.tarefaDAO().insert(tarefa);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        descricaoTarefa.setText("");
                        Toast.makeText(MainActivity.this, "Tarefa salva", Toast.LENGTH_SHORT).show();
                        carregarTarefas();
                    }
                });
            }
        }).start();
    }

    private void carregarTarefas() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Tarefa> tarefas = db.tarefaDAO().buscaTodasTarefas();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.atualizarLista(tarefas);
                    }
                });
            }
        }).start();
    }

    private void atualizarTarefa(final Tarefa tarefa) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                db.tarefaDAO().update(tarefa);
                carregarTarefas();
            }
        }).start();
    }

    private void deletarTarefa(final Tarefa tarefa) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                db.tarefaDAO().delete(tarefa);
                carregarTarefas();
            }
        }).start();
    }
}
