package com.example.appdetarefas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TarefaAdapter extends RecyclerView.Adapter<TarefaAdapter.TarefaViewHolder> {

    private List<Tarefa> listaTarefas;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onCheckBoxClick(Tarefa tarefa, boolean isChecked);
        void onDeleteClick(Tarefa tarefa);
    }

    public TarefaAdapter(List<Tarefa> listaTarefas, OnItemClickListener listener) {
        this.listaTarefas = listaTarefas;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TarefaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tarefa, parent, false);
        return new TarefaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TarefaViewHolder holder, int position) {
        Tarefa tarefa = listaTarefas.get(position);
        holder.textViewDescricao.setText(tarefa.getDescricao());
        holder.checkBoxFeita.setChecked(tarefa.isFeita());

        holder.checkBoxFeita.setOnCheckedChangeListener((buttonView, isChecked) -> {
            listener.onCheckBoxClick(tarefa, isChecked);
        });

        holder.buttonDelete.setOnClickListener(v -> {
            listener.onDeleteClick(tarefa);
        });
    }

    @Override
    public int getItemCount() {
        return listaTarefas.size();
    }

    public static class TarefaViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBoxFeita;
        TextView textViewDescricao;
        ImageButton buttonDelete;

        public TarefaViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBoxFeita = itemView.findViewById(R.id.checkBoxFeita);
            textViewDescricao = itemView.findViewById(R.id.textViewDescricao);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }

    public void atualizarLista(List<com.example.appdetarefas.Tarefa> novasTarefas){
        listaTarefas = novasTarefas;
        notifyDataSetChanged();
    }
}
