package com.example.appdetarefas;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tarefas")
public class Tarefa {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "descricao")
    private String descricao;

    @ColumnInfo(name = "feita")
    private boolean feita;

    public Tarefa(int id, String descricao, boolean feita) {
        this.id = id;
        this.descricao = descricao;
        this.feita = feita;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public boolean isFeita() {
        return feita;
    }
    public void setFeita(boolean feita) {
        this.feita = feita;
    }
}
